
var Tweet = Backbone.Model.extend();